package resourceid

type Formatter interface {
	ID() string
}
